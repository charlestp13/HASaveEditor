export function HomePage() {
  return (
    <div className="container mx-auto p-8">
    </div>
  )
}